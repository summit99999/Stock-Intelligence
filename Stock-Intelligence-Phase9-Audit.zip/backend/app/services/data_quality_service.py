"""
Market Data Quality Assurance & Diagnostic Engine (Audited Priority 6).

Audits:
- Exchange-calendar-aware missing sessions (NSE trading schedule)
- Duplicate and out-of-order timestamps
- Full OHLC mathematical consistency (high >= max(open, close), low <= min(open, close))
- Zero and anomalous volume spikes (>20x median)
- Data freshness relative to current market sessions
- Corporate-action adjustment limitations (flag unadjusted splits/bonuses)
- Provider attribution: Strict truthfulness — Never label delayed/stale data as live
"""

from __future__ import annotations

from datetime import datetime, timezone, date
import logging
from typing import Any, Optional
import numpy as np
import pandas as pd

from app.database import get_bars, list_stocks

logger = logging.getLogger(__name__)

# Standard Indian Equity (NSE) Fixed Holidays for calendar-aware missing session checks
NSE_FIXED_HOLIDAYS = {
    "01-26",  # Republic Day
    "05-01",  # Maharashtra Day
    "08-15",  # Independence Day
    "10-02",  # Gandhi Jayanti
    "12-25",  # Christmas
}


def audit_single_symbol_data_quality(
    bars: list[dict],
    symbol: str = "UNKNOWN",
    provider: str = "YFINANCE",
    is_live_stream: bool = False,
) -> dict:
    """
    Perform deep quantitative data quality inspection on an OHLCV dataset.
    """
    if not bars or len(bars) == 0:
        return {
            "symbol": symbol,
            "status": "MISSING_DATA",
            "quality_grade": "F",
            "bars_count": 0,
            "first_timestamp": None,
            "last_timestamp": None,
            "data_provider": provider.upper(),
            "is_live": False,
            "anomalies": ["No historical bars found in dataset"],
            "ohlc_consistency": {"passed": False, "violations_count": 0},
            "temporal_integrity": {"is_sorted": False, "duplicates_count": 0, "out_of_order_count": 0},
            "calendar_integrity": {"missing_sessions_count": 0, "missing_session_dates": []},
            "volume_integrity": {"zero_volume_bars": 0, "anomalous_spikes_count": 0},
            "corporate_actions": {"unadjusted_gap_flags": []},
            "freshness": {"is_fresh": False, "business_days_lag": 999},
        }

    df = pd.DataFrame(bars)
    if "date" in df.columns and "timestamp" not in df.columns:
        df = df.rename(columns={"date": "timestamp"})

    n_bars = len(df)
    anomalies = []

    # 1. Temporal Integrity: Duplicate & Out-of-Order Timestamps
    ts_series = pd.to_datetime(df["timestamp"], errors="coerce")
    duplicates_count = int(df["timestamp"].duplicated().sum())
    is_monotonic = bool(ts_series.is_monotonic_increasing)
    out_of_order_count = 0
    if not is_monotonic:
        diffs = ts_series.diff().dt.total_seconds()
        out_of_order_count = int((diffs < 0).sum())
        anomalies.append(f"{out_of_order_count} out-of-order timestamp sequence(s) detected")

    if duplicates_count > 0:
        anomalies.append(f"{duplicates_count} duplicate timestamp(s) detected")

    # 2. Full OHLC Consistency Checks
    ohlc_violations = 0
    ohlc_violation_details = []

    for col in ("open", "high", "low", "close"):
        if col in df.columns:
            non_pos = int((df[col] <= 0).sum())
            if non_pos > 0:
                ohlc_violations += non_pos
                ohlc_violation_details.append(f"{non_pos} bar(s) with price <= 0 in {col}")

    if "high" in df.columns and "low" in df.columns:
        inverted = int((df["high"] < df["low"]).sum())
        if inverted > 0:
            ohlc_violations += inverted
            ohlc_violation_details.append(f"{inverted} bar(s) with High < Low")

    if all(c in df.columns for c in ("open", "high", "low", "close")):
        high_invalid = int(((df["high"] < df["open"]) | (df["high"] < df["close"])).sum())
        if high_invalid > 0:
            ohlc_violations += high_invalid
            ohlc_violation_details.append(f"{high_invalid} bar(s) where High < max(Open, Close)")

        low_invalid = int(((df["low"] > df["open"]) | (df["low"] > df["close"])).sum())
        if low_invalid > 0:
            ohlc_violations += low_invalid
            ohlc_violation_details.append(f"{low_invalid} bar(s) where Low > min(Open, Close)")

    anomalies.extend(ohlc_violation_details)

    # 3. Exchange-Calendar-Aware Missing Sessions Check
    missing_sessions = []
    if is_monotonic and len(ts_series.dropna()) >= 2:
        valid_dates = ts_series.dropna().dt.date
        for i in range(1, len(valid_dates)):
            d_prev = valid_dates.iloc[i - 1]
            d_curr = valid_dates.iloc[i]
            # Expected trading days between previous and current bar
            b_days = pd.bdate_range(d_prev, d_curr, inclusive="neither")
            for b_day in b_days:
                mm_dd = b_day.strftime("%m-%d")
                if mm_dd not in NSE_FIXED_HOLIDAYS:
                    missing_sessions.append(b_day.strftime("%Y-%m-%d"))

    if len(missing_sessions) > 0:
        anomalies.append(f"{len(missing_sessions)} potential exchange-calendar missing session(s)")

    # 4. Zero and Anomalous Volume Spikes
    zero_vol_count = 0
    anomalous_spikes = 0
    if "volume" in df.columns:
        zero_vol_count = int((df["volume"] == 0).sum())
        if zero_vol_count > 0:
            anomalies.append(f"{zero_vol_count} bar(s) with 0 volume")

        vol_series = df["volume"]
        rolling_median = vol_series.rolling(20, min_periods=5).median()
        spikes = (vol_series > 20.0 * rolling_median) & (rolling_median > 0)
        anomalous_spikes = int(spikes.sum())
        if anomalous_spikes > 0:
            anomalies.append(f"{anomalous_spikes} anomalous volume spike(s) (>20x 20-day median)")

    # 5. Corporate-Action Adjustment Limitations (Flag large unadjusted price jumps)
    unadjusted_gaps = []
    if "close" in df.columns and "open" in df.columns and len(df) >= 2:
        prev_close = df["close"].shift(1)
        curr_open = df["open"]
        overnight_pct = ((curr_open - prev_close) / prev_close) * 100.0
        # Flag drops > 40% (e.g. 2:1, 5:1 stock split) or surges > 80%
        suspected_splits = df[(overnight_pct < -40.0) | (overnight_pct > 80.0)]
        for idx in suspected_splits.index:
            t_str = str(df["timestamp"].iloc[idx])
            gap_pct = round(float(overnight_pct.iloc[idx]), 1)
            unadjusted_gaps.append({"timestamp": t_str, "gap_pct": gap_pct})
            anomalies.append(f"Unadjusted corporate-action gap ({gap_pct}%) on {t_str}")

    # 6. Data Freshness Check
    first_t = str(df["timestamp"].iloc[0])
    last_t = str(df["timestamp"].iloc[-1])
    try:
        last_dt = pd.to_datetime(last_t).date()
        today_dt = datetime.now(timezone.utc).date()
        b_days_lag = len(pd.bdate_range(last_dt, today_dt, inclusive="neither"))
        is_fresh = b_days_lag <= 3
        if not is_fresh:
            anomalies.append(f"Stale data: last bar is {b_days_lag} business day(s) old")
    except Exception:
        b_days_lag = 0
        is_fresh = True

    # 7. Provider Attribution Truthfulness
    # Never mark historical or delayed data as live
    is_live = False
    if provider.lower() == "dhan" and is_live_stream:
        is_live = True

    # Quality Grade assignment
    if len(anomalies) == 0 and n_bars >= 100 and is_fresh:
        grade = "A+"
        status = "HEALTHY"
    elif len(anomalies) <= 1 and n_bars >= 40:
        grade = "A"
        status = "HEALTHY"
    elif len(anomalies) <= 3:
        grade = "B"
        status = "WARNING"
    else:
        grade = "C"
        status = "DEGRADED"

    return {
        "symbol": symbol,
        "status": status,
        "quality_grade": grade,
        "bars_count": n_bars,
        "first_timestamp": first_t,
        "last_timestamp": last_t,
        "data_provider": provider.upper(),
        "is_live": is_live,
        "anomalies": anomalies,
        "ohlc_consistency": {
            "passed": ohlc_violations == 0,
            "violations_count": ohlc_violations,
            "details": ohlc_violation_details,
        },
        "temporal_integrity": {
            "is_sorted": is_monotonic,
            "duplicates_count": duplicates_count,
            "out_of_order_count": out_of_order_count,
        },
        "calendar_integrity": {
            "missing_sessions_count": len(missing_sessions),
            "missing_session_dates": missing_sessions[:10],
        },
        "volume_integrity": {
            "zero_volume_bars": zero_vol_count,
            "anomalous_spikes_count": anomalous_spikes,
        },
        "corporate_actions": {
            "unadjusted_gap_flags": unadjusted_gaps,
        },
        "freshness": {
            "is_fresh": is_fresh,
            "business_days_lag": b_days_lag,
        },
    }


def generate_market_data_quality_report() -> dict:
    """
    Audit data quality across all configured stocks in the universe.
    """
    stocks = list_stocks()
    total_requested = len(stocks)
    audited_stocks = []
    healthy_count = 0
    warning_count = 0
    error_count = 0

    now_utc = datetime.now(timezone.utc)

    for stk in stocks:
        sym = stk["symbol"]
        provider = stk.get("data_source", "yfinance")
        bars = get_bars(sym)

        stk_report = audit_single_symbol_data_quality(
            bars=bars,
            symbol=sym,
            provider=provider,
            is_live_stream=bool(provider == "dhan" and stk.get("live_available", False)),
        )
        stk_report["company_name"] = stk.get("company_name", sym)
        stk_report["sector"] = stk.get("sector", "General")

        if stk_report["status"] == "HEALTHY":
            healthy_count += 1
        elif stk_report["status"] == "WARNING":
            warning_count += 1
        else:
            error_count += 1

        audited_stocks.append(stk_report)

    overall_health = (
        "EXCELLENT"
        if healthy_count >= total_requested * 0.85
        else ("GOOD" if healthy_count >= total_requested * 0.60 else "DEGRADED")
    )

    return {
        "report_generated_utc": now_utc.isoformat(),
        "total_stocks_evaluated": total_requested,
        "healthy_stocks": healthy_count,
        "warning_stocks": warning_count,
        "error_stocks": error_count,
        "overall_health": overall_health,
        "data_providers": {
            "primary": "yfinance (historical OHLCV)",
            "live_stream": "DhanHQ WebSocket (when configured & enabled)",
            "live_policy": "Zero-Cost default; offline/historical data never labeled as LIVE",
        },
        "stocks": audited_stocks,
    }

