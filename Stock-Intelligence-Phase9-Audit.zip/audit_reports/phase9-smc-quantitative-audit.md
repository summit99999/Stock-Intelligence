# Phase 9: Quantitative Validation, Backtesting Integrity & Reliability Audit Report

**System**: Stock Intelligence Pro — Quantitative Smart Money Concepts (SMC) Engine
**Date**: November 2026
**Lead Researcher**: Quantitative Trading Engineer & Algorithms Specialist
**Audit Scope**: Non-repainting verification, point-in-time timestamps, Order Block lifecycle priority, realistic backtest execution, Indian market fee models, walk-forward validation, parameter sensitivity, data quality, and skipped test resolution.

---

## 1. Executive Findings & Codebase Vulnerability Audit

| Audit Area | Subsystem | Code Location | Vulnerability / Finding | Severity | Proposed Architectural Fix |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Look-Ahead Bias in Swings** | `smc_service.py` | `detect_market_structure()` lines 156-165 | Swing high at bar $i$ confirmed with lookback $k$ was made available for breaks immediately at bar $i$ rather than at $i + k$. | **HIGH** | Explicitly track `occurrence_index`, `confirmation_index = i + k`, and `signal_available_index = i + k + 1`. Only swings with `confirmation_index <= current_bar` can be broken. |
| **Point-in-Time Liquidity Benchmarks** | `smc_service.py` | `detect_liquidity_and_sweeps()` lines 657-681 | `equal_highs` across entire series were checked for sweeps without validating that the forming swing pivots had completed confirmation prior to the sweep candle. | **MEDIUM** | Filter `equal_highs` and `equal_lows` dynamically to only those whose constituent swings were fully confirmed before the candidate sweep bar. |
| **Order Block Lifecycle Priority** | `smc_service.py` | `detect_order_blocks()` lines 279-296 | If a candle simultaneously penetrates $\ge 50\%$ and closes beyond invalidation, order of conditions must strictly guarantee `INVALIDATED > MITIGATED`. Gap-through beyond zone was unhandled if candle wicked back. | **MEDIUM** | Enforce deterministic priority: `INVALIDATED` (by close or gap-through) $\rightarrow$ `MITIGATED` ($\ge 50\%$) $\rightarrow$ `TESTED` $\rightarrow$ `FRESH`. Add gap-through detection. |
| **Backtest Execution Realism** | `smc_backtest_service.py` | `run_smc_backtest()` lines 103-120 | Backtester entered on same-bar retest and rejected setups retroactively if the entry bar also touched stop loss (`k_low >= stop_price`), introducing look-ahead selection bias. | **HIGH** | Implement next-executable-candle entry rule (`signal_available_index`). If a trade is entered and touches stop loss on the same bar, it must record a loss, not be filtered out. |
| **Same-Candle SL/TP Ambiguity** | `smc_backtest_service.py` | Lines 138-163 | Both SL and TP within single candle range needs strict conservative resolution. Gap-down below SL was filled at SL rather than at gap `open`. | **MEDIUM** | If gap-down opens below SL, exit at `open` (slippage). If candle spans both SL and TP, conservative institutional rule: SL triggers first. |
| **Indian Market Fee Structure** | `smc_backtest_service.py` | Lines 80, 174 | Fixed 5 bps was deducted. Missing Indian statutory charges (STT, GST, SEBI turnover fees, Stamp Duty, NSE transaction charges). | **MEDIUM** | Implement configurable `IndianEquityCostModel` computing STT (0.1% delivery / 0.025% intraday), GST (18%), stamp duty (0.015%), NSE exchange fees (0.00297%), and slippage. |
| **Concurrent / Overlapping Trades** | `smc_backtest_service.py` | Lines 92-195 | Concurrently active order blocks could trigger overlapping trades, distorting compounding and capital allocation. | **MEDIUM** | Add `allow_overlapping=False` default to ensure strict single-position or bounded-allocation walk-forward execution. |
| **Skipped Tests Audit** | `test_market_data.py` | Lines 193, 207, 214, 222 | 4 tests skipped due to `RUN_NETWORK_TESTS != 1` attempting live HTTP calls to `yfinance.download`. | **LOW** | Document external dependency; add mocked offline unit tests to achieve 100% executable test coverage without network dependency. |

---

## 2. Non-Repainting Timestamp Specification (Milestone 2)

To guarantee zero look-ahead bias and mathematical reproducibility across backtesting and live chart annotations, every structural signal must maintain three distinct timestamp dimensions:

$$\begin{aligned}
t_{\text{occurrence}} &\le t_{\text{confirmation}} < t_{\text{signal\_available}} \\
\text{Index: } i_{\text{occurrence}} &\le i_{\text{confirmation}} < i_{\text{signal\_available}}
\end{aligned}$$

1. **Swing Pivot ($i, \text{lookback } k$)**:
   - `occurrence_index`: $i$ (Candle where price peak/trough occurred)
   - `confirmation_index`: $i + k$ (Candle whose close confirms no higher/lower candle in $k$ bars)
   - `signal_available_index`: $i + k + 1$ (The earliest candle open where trading systems could know of the swing)

2. **Break of Structure (BOS) & Change of Character (CHoCH)**:
   - `occurrence_index`: $b$ (Candle that broke the level)
   - `confirmation_index`: $b$ (Candle $b$ must complete its close above/below the confirmed swing level)
   - `signal_available_index`: $b + 1$ (Earliest trade entry bar)

3. **Order Block (OB)**:
   - `occurrence_index`: Candidate candle $j$ ($j < b$)
   - `confirmation_index`: Break candle $b$ (displacement $\ge 1.0\times$ ATR completed)
   - `signal_available_index`: $b + 1$ (Earliest retest entry)

4. **Fair Value Gap (FVG)**:
   - `occurrence_index`: Bar $i - 1$ (The imbalance candle)
   - `confirmation_index`: Bar $i$ (3rd candle close confirming gap between $i-2$ and $i$)
   - `signal_available_index`: Bar $i + 1$ (Earliest fill entry)

5. **Liquidity Sweep**:
   - `occurrence_index`: Bar $s$ (Candle wicking beyond benchmark level)
   - `confirmation_index`: Bar $s$ (Candle $s$ close finishing back inside)
   - `signal_available_index`: Bar $s + 1$ (Opposing confirmation entry)

---

## 3. Order Block Lifecycle Deterministic Priority (Milestone 3)

The lifecycle of an Order Block must be strictly deterministic when multiple conditions occur on the same candle:

```mermaid
stateDiagram-v2
    [*] --> FRESH: Breakout Confirmed (Displacement >= 1.0x ATR)
    FRESH --> TESTED: Retest (Price touches zone, Invalidation intact)
    TESTED --> TESTED: Additional Retests (Price re-enters from outside)
    TESTED --> MITIGATED: Penetration >= 50% depth
    FRESH --> MITIGATED: Direct 50% Penetration without prior test
    FRESH --> INVALIDATED: Candle Close beyond zone boundary OR Gap-Through
    TESTED --> INVALIDATED: Candle Close beyond zone boundary OR Gap-Through
    MITIGATED --> INVALIDATED: Candle Close beyond zone boundary OR Gap-Through
```

**Deterministic Evaluation Hierarchy per candle $k$**:
1. **Invalidation Check (Priority 1)**:
   - If candle closes beyond invalidation level ($C_k < \text{Low}_{\text{zone}}$ for Bullish OB, or $C_k > \text{High}_{\text{zone}}$ for Bearish OB), OR if entire candle gaps through zone ($\text{High}_k < \text{Low}_{\text{zone}}$ or $\text{Low}_k > \text{High}_{\text{zone}}$):
     $\rightarrow \mathbf{INVALIDATED}$. Lifecycle terminates.
2. **Mitigation Check (Priority 2)**:
   - If price penetrates into zone such that $\text{depth} \ge 50.0\%$:
     $\rightarrow \mathbf{MITIGATED}$.
3. **Retest Check (Priority 3)**:
   - If price touches or trades into zone ($\text{Low}_k \le \text{High}_{\text{zone}}$):
     $\rightarrow \mathbf{TESTED}$. Retest count increments when price entered from outside the zone.
4. **Status Quo (Priority 4)**:
   - If price did not touch the zone: remains $\mathbf{FRESH}$.

---

## 4. Realistic Indian Market Cost Model (Milestone 5)

Indian equities carry statutory regulatory charges that substantially impact quantitative edge. Our realistic execution model calculates:

| Component | Intraday Equity Rate | Delivery Equity Rate | Source / Regulatory Authority |
| :--- | :--- | :--- | :--- |
| **Brokerage** | $\min(₹20, 0.03\%)$ per executed order | ₹0 (Discount) or $\min(₹20, 0.03\%)$ | Broker / Exchange Standard |
| **STT (Securities Transaction Tax)** | 0.025% on Sell side only | 0.1% on both Buy and Sell | Ministry of Finance, Govt of India |
| **Exchange Transaction Fee** | 0.00297% (NSE) | 0.00297% (NSE) | National Stock Exchange |
| **SEBI Turnover Charges** | ₹10 per crore (0.0001%) | ₹10 per crore (0.0001%) | SEBI |
| **Stamp Duty** | 0.003% on Buy side only | 0.015% on Buy side only | Indian Stamp Act |
| **GST (Goods & Services Tax)** | 18% on (Brokerage + Exchange Fees + SEBI) | 18% on (Brokerage + Exchange Fees + SEBI) | Govt of India |
| **Execution Slippage** | 0.05% (5 bps) per leg | 0.05% (5 bps) per leg | Conservative liquidity friction |

---

## 5. Next Steps for Implementation

1. Update `backend/app/services/smc_service.py` with multi-dimensional timestamps (`occurrence`, `confirmation`, `signal_available`) and deterministic lifecycle priority.
2. Update `backend/app/services/smc_backtest_service.py` with realistic execution, Indian statutory fees, slippage, conservative same-candle resolution, and 5 independent strategies.
3. Add walk-forward regime validation (Milestone 7) and parameter sensitivity analysis (Milestone 8).
4. Add market data quality diagnostic service & endpoint (Milestone 9).
5. Audit and mock the 4 skipped tests (Milestone 10).
6. Run full verification suite (Pytest & Frontend build).
