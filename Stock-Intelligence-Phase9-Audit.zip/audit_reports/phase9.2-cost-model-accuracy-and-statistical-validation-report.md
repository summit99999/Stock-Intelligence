# Stock Intelligence Pro — Phase 9.2 Delivery Report
## Final Cost-Model Accuracy & Statistical Validation Corrections

**Project:** `Stock Intelligence Pro` (`D:\ST\Stock-Intelligence-Starter\Stock-Intelligence`)  
**Date:** November 2026  
**Status:** **AUDITED, CORRECTED & VERIFIED**  
**Test Suite:** **255 PASSED**, 4 SKIPPED, 0 FAILED (Duration: 36.05s)  
**Frontend Build:** Production build passed cleanly (`tsc && vite build` in 1.32s)

---

## Executive Summary

Phase 9.2 addresses all final cost-model accuracy requirements and establishes institutional statistical validation standards across Stock Intelligence Pro.

### Primary Corrections Delivered
1. **Dhan Default Broker Profile:** Implemented Dhan's published retail schedule as the system default (`brokerage_model="dhan"`):
   - Delivery brokerage: ₹0.
   - Intraday brokerage: min(₹20, 0.03% per leg) per executed order.
   - DP charges: ₹12.50 + 18% GST = ₹14.75 per ISIN debit instruction.
   - Zerodha (₹13.50 + 18% GST = ₹15.93), Flat ₹20, and Percentage profiles preserved as optional configurations.
2. **Current & Historical Date-Effective NSE Schedules:**
   - **From 1 March 2026 onwards:** Cash transaction charges of **₹306.99 per crore** per side plus NSE IPFT of **₹0.01 per crore** per side, totaling **₹307.00 per crore** combined exchange-related outflow.
   - **1 October 2024 to 28 February 2026:** Cash transaction charges of **₹297.00 per crore** per side plus IPFT of **₹0.10 per crore**.
   - **Prior to 1 October 2024:** Cash transaction charges of **₹345.00 per crore** per side plus IPFT of **₹0.10 per crore**.
   - Preserves applicable GST treatment (18% on taxable financial services: Brokerage, Exchange Txn Charges, SEBI fees).
3. **Settlement and ISIN-Aware DP Modeling:**
   - Modeled strictly by settlement date and ISIN debit instruction: multiple delivery sell fills in the same symbol on the same settlement day incur only **one** DP charge debit (₹14.75), rather than blindly charging per trade. Intraday incurs ₹0.
4. **Institutional Sample-Size Tiers & Confidence Intervals:**
   - Enforces that small samples (< 30 trades) **never** qualify as statistically robust.
   - Categorizes sample size into 4 institutional warning tiers: `CRITICALLY_LOW` (< 15), `INSUFFICIENT` (15–29), `MODERATE` (30–49), and `ADEQUATE` ($\ge 50$).
   - Calculates **Wilson Score 95% Confidence Intervals** for win rates.
   - Implements **Bootstrap 95% Confidence Intervals** (1,000 resamples) for Net Expectancy (₹) and Net Profit Factor.
   - Explicitly classifies underpowered or inconclusive tests as `INSUFFICIENT EVIDENCE / STATISTICALLY UNPROVEN`.
5. **Documented Configurable Sharpe Benchmark Rate:**
   - Configurable assumed annual benchmark rate (`risk_free_rate: float = 0.06`, 6.0% annual e.g. RBI 91-day T-Bill or repo rate proxy).
   - Daily rate: $R_{f,\text{daily}} = \frac{R_f}{252}$.
   - Continuous daily return series across all trading days: non-trading/idle cash days receive $0.0\%$ return and are penalized by $-R_{f,\text{daily}}$ to reflect cash drag against the benchmark.
6. **Regression Testing & Verification:**
   - Expanded [test_smc_audit_corrections.py](file:///D:/ST/Stock-Intelligence-Starter/Stock-Intelligence/backend/tests/test_smc_audit_corrections.py) to 16 deterministic tests (all passing). Full suite of **255 tests passed**.

---

## 1. Indian Statutory Transaction Cost Model (Dhan Profile)

### A. Published Pricing & Statutory Schedules

The cost model in [calculate_indian_transaction_costs()](file:///D:/ST/Stock-Intelligence-Starter/Stock-Intelligence/backend/app/services/smc_backtest_service.py#L145-L270) models Dhan retail pricing with complete date-effective exchange schedules:

```mermaid
graph TD
    A[Order Input: Entry & Exit Turnover] --> B{Trade Schedule}
    B -->|Delivery / Swing| C[Brokerage = ₹0]
    B -->|Intraday| D[Brokerage = min ₹20, 0.03%]
    B -->|Delivery| E[STT = 0.1% Buy + 0.1% Sell]
    B -->|Intraday| F[STT = 0.025% Sell Only]
    B -->|Delivery| G[Stamp Duty = 0.015% Buy]
    B -->|Intraday| H[Stamp Duty = 0.003% Buy]
    A --> I[NSE Date Schedule]
    I -->|>= 1 March 2026| J[₹306.99/cr Txn + ₹0.01/cr IPFT = ₹307/cr]
    I -->|1 Oct 2024 - 28 Feb 2026| K[₹297/cr Txn + ₹0.10/cr IPFT]
    I -->|< 1 Oct 2024| L[₹345/cr Txn + ₹0.10/cr IPFT]
    A --> M[SEBI Turnover Fee = ₹10/cr]
    C & D & J & K & L & M --> N[GST = 18% on Brokerage + Exchange Txn + SEBI]
    B -->|Delivery Sell Debit| O[Dhan DP = ₹12.50 + 18% GST = ₹14.75 per ISIN/Day]
    B -->|Intraday| P[DP = ₹0.00]
    A --> Q[Slippage = 5 bps per leg on actual turnover]
    N & E & F & G & H & O & P & Q --> R[Total Realized Friction]
```

### B. Phase 9.2 Reliance Numerical Verification Table
**Trade Parameters:** 100 shares bought at ₹2,500.00 (Buy turnover: ₹2,50,000.00), sold at ₹2,600.00 (Sell turnover: ₹2,60,000.00). Total turnover: ₹5,10,000.00.  
**Effective Date:** 15 March 2026 (Current NSE schedule).  
**Broker Profile:** Dhan Retail.

```
===================================================================================================
Cost Component                 Dhan Delivery (Swing Default)   Dhan Intraday            Variance
===================================================================================================
Brokerage (Dhan Retail)                                ₹0.00          ₹40.00             -₹40.00
STT / CTT                                            ₹510.00          ₹65.00            +₹445.00
Stamp Duty                                            ₹37.50           ₹7.50             +₹30.00
NSE Transaction Charge (₹306.99/cr)                   ₹15.66          ₹15.66               ₹0.00
NSE IPFT (₹0.01/cr)                                  ₹0.0005         ₹0.0005               ₹0.00
Combined Exchange Outflow (₹307.00/cr)                ₹15.66          ₹15.66               ₹0.00
SEBI Turnover Fee (₹10/cr)                             ₹0.51           ₹0.51               ₹0.00
GST (18% on Brokerage + Txn + SEBI)                    ₹2.91          ₹10.11              -₹7.20
DP Charges (₹12.50 base + 18% GST)                    ₹14.75           ₹0.00             +₹14.75
---------------------------------------------------------------------------------------------------
Total Statutory Charges                              ₹581.33         ₹138.78            +₹442.55 (+318.9%)
---------------------------------------------------------------------------------------------------
Slippage Entry Leg (5 bps on ₹2.5L)                  ₹125.00         ₹125.00               ₹0.00
Slippage Exit Leg (5 bps on ₹2.6L)                   ₹130.00         ₹130.00               ₹0.00
Total Execution Slippage                             ₹255.00         ₹255.00               ₹0.00
---------------------------------------------------------------------------------------------------
TOTAL REALIZED FRICTION                              ₹836.33         ₹393.78            +₹442.55
Effective Basis Points                             16.40 bps        7.72 bps           +8.68 bps
===================================================================================================
```

> [!NOTE]
> Under Dhan's retail schedule, statutory charges for delivery are **₹581.33** (compared to Zerodha's ₹581.91 due to Dhan's lower DP fee of ₹14.75 vs Zerodha's ₹15.93). The variance between delivery and intraday remains massive at **+318.9%**, confirming that using intraday cost assumptions for swing strategies creates severe look-ahead bias and phantom alpha.

---

## 2. Settlement-Aware DP Charge Modeling

Under Indian equity depository regulations (CDSL/NSDL):
- Depository Participant (DP) charges apply on **debit of shares from the demat pool** (i.e. sell leg of delivery trades).
- Debits are batched at end-of-day per settlement day per ISIN.
- If an investor executes multiple sell orders for the same scrip on the same trading day (e.g. partial exits or scaling out), CDSL/NSDL issues **one settlement debit instruction** for that ISIN on that settlement date.
- In [run_smc_backtest()](file:///D:/ST/Stock-Intelligence-Starter/Stock-Intelligence/backend/app/services/smc_backtest_service.py#L740-L770), this is modeled deterministically:
  ```python
  exit_date = str(timestamps.iloc[exit_bar])[:10]
  is_delivery_sell = (direction == "BULLISH" and trade_type == "delivery")
  dp_instruction_key = (sym, exit_date)
  if is_delivery_sell:
      if dp_instruction_key in settled_dp_instructions:
          is_debit = False  # Already debited in this settlement batch
      else:
          is_debit = True
          settled_dp_instructions.add(dp_instruction_key)
  else:
      is_debit = False
  ```
- **Verification:** Verified by unit test `test_dp_charge_settlement_and_isin_modeling()`: Trade 1 debits ₹14.75, Trade 2 on the same day debits ₹0.00, and a trade on the next day debits ₹14.75.

---

## 3. Date-Effective NSE Cash Fee Schedule Tiers

| Effective Date Range | Transaction Charge (per crore per side) | NSE IPFT (per crore per side) | Combined Outflow (per crore per side) | Statutory Authority / Circular |
|---|---|---|---|---|
| **From 1 March 2026** | **₹306.99** (`0.0030699%`) | **₹0.01** (`0.0000001%`) | **₹307.00** (`0.00307%`) | Current NSE cash market revision |
| **1 Oct 2024 – 28 Feb 2026** | **₹297.00** (`0.00297%`) | **₹0.10** (`0.000001%`) | **₹297.10** | SEBI true-to-label circular |
| **Prior to 1 Oct 2024** | **₹345.00** (`0.00345%`) | **₹0.10** (`0.000001%`) | **₹345.10** | Historical NSE transaction fee schedule |

**GST Treatment:**
GST of 18% is applied strictly to taxable financial service items:
$$\text{GST Base} = \text{Brokerage} + \text{Exchange Transaction Charges} + \text{SEBI Turnover Fees}$$
IPFT is non-taxable / exempt trust contribution. The system supports `ipft_subject_to_gst: bool = False` (configurable).

---

## 4. Institutional Statistical Robustness Standards

### A. The 5-Trade Rule Elimination
In Phase 9.1, 5 out-of-sample trades were previously sufficient to trigger a "STATISTICALLY ROBUST" verdict. Phase 9.2 permanently abolishes this practice:
> **Institutional Rule:** A sample size of less than 30 out-of-sample trades **can never establish statistical significance**, regardless of the observed point estimate of the profit factor.

### B. Sample Size Warning Tiers
Implemented in [evaluate_sample_size_validity()](file:///D:/ST/Stock-Intelligence-Starter/Stock-Intelligence/backend/app/services/smc_backtest_service.py#L115-L145):

| Sample Size ($N$) | Institutional Tier | Reliability | Status & Operational Guidance |
|---|---|---|---|
| **$N < 15$** | `CRITICALLY_LOW` | **Unreliable** | Massive standard errors; performance statistics are statistically meaningless. |
| **$15 \le N < 30$** | `INSUFFICIENT` | **Inconclusive** | CLT and asymptotic normality do not hold; minimum 30 trades required. |
| **$30 \le N < 50$** | `MODERATE` | **Preliminary** | Preliminary statistical tests valid, but confidence intervals remain wide. |
| **$N \ge 50$** | `ADEQUATE` | **Reliable** | Sufficient for standard out-of-sample statistical testing and hypothesis rejection. |

### C. Wilson Score 95% Confidence Interval for Win Rate
For binomial proportions $\hat{p} = \frac{k}{n}$, the Wilson score interval provides asymmetric coverage with continuity preservation:
$$\text{CI}_{95\%} = \frac{\hat{p} + \frac{z^2}{2n} \pm z\sqrt{\frac{\hat{p}(1-\hat{p})}{n} + \frac{z^2}{4n^2}}}{1 + \frac{z^2}{n}}, \quad z = 1.95996$$
- **Example:** For an observed 66.7% win rate on 3 trades, the Wilson 95% CI is **[20.8%, 93.9%]**, exposing extreme sampling variance.
- For 20 wins out of 30 trades (66.7%), the Wilson 95% CI narrows to **[48.8%, 80.8%]**.

### D. Bootstrap 95% Confidence Intervals (1,000 Resamples)
For all runs with $N \ge 5$ trades, the engine runs $B = 1,000$ bootstrap resamples with replacement:
- **Net Expectancy (₹):** Percentile 95% CI $[E_{2.5\%}, E_{97.5\%}]$.
- **Net Profit Factor:** Percentile 95% CI $[PF_{2.5\%}, PF_{97.5\%}]$.
- **$P(\text{Profitable System})$:** Percentage of bootstrap iterations where $PF > 1.00$.

### E. Multi-Criteria Out-of-Sample Robustness Classification
A strategy in [run_walk_forward_validation()](file:///D:/ST/Stock-Intelligence-Starter/Stock-Intelligence/backend/app/services/smc_backtest_service.py#L1250-L1380) is classified as `STATISTICALLY ROBUST` **if and only if all 7 criteria are met simultaneously**:
1. Out-of-sample sample size $N \ge 30$ trades.
2. Out-of-sample Net Profit Factor point estimate $\ge 1.15$.
3. 95% Bootstrap CI lower bound for Net Profit Factor $> 1.00$.
4. 95% Bootstrap CI lower bound for Net Expectancy $> ₹0.00$.
5. Bootstrap confidence of positive profit factor $P(PF > 1.00) \ge 90.0\%$.
6. Profit factor degradation from in-sample to out-of-sample $\le 30.0\%$.
7. Positive net P&L in at least $60.0\%$ of rolling test windows.

If any criterion fails, the engine outputs an explicit, itemized verdict:
`"STATISTICALLY INCONCLUSIVE / RISK OF OVERFITTING: [List of specific failed statistical criteria]"`.

---

## 5. Configurable Sharpe Benchmark & Continuous Daily Series

Implemented in [run_smc_backtest()](file:///D:/ST/Stock-Intelligence-Starter/Stock-Intelligence/backend/app/services/smc_backtest_service.py#L980-L1025):
- **Assumed Benchmark:** `risk_free_rate: float = 0.06` (Configurable default: 6.0% annual e.g. RBI 91-day T-Bill / repo proxy).
- **Daily Benchmark Rate:** $R_{f,\text{daily}} = \frac{R_f}{252} = 0.000238$ (2.38 bps/day).
- **Continuous Calendar/Trading-Day Series:** Daily equity is recorded continuously from bar 0 to $n-1$.
- **Treatment of Non-Trading Days:** On days without trade exits, capital is uninvested and portfolio return is $0.0\%$. The daily excess return is:
  $$\text{Excess Return} = 0.0 - R_{f,\text{daily}} = -R_{f,\text{daily}}$$
  This accurately reflects the opportunity cost of idle capital versus the risk-free rate.
- **Annualization:** $\sqrt{252}$ scaling applied to both Sharpe and Sortino ratios.

---

## 6. Complete Verification & Regression Test Results

### Pytest Execution Output (259 Tests)
```
backend/tests/test_dhan_auth.py ........................................ [ 15%]
...............                                                          [ 21%]
backend/tests/test_dhan_market_feed.py ......................            [ 29%]
backend/tests/test_dhan_resilience.py ................                   [ 35%]
backend/tests/test_fundamental_engine.py .......................         [ 44%]
backend/tests/test_fundamentals.py ..................................    [ 57%]
backend/tests/test_indicators.py ....................                    [ 65%]
backend/tests/test_market_data.py ..........ssss......                   [ 73%]
backend/tests/test_phase5b_validation.py ............                    [ 77%]
backend/tests/test_screener.py .................                         [ 84%]
backend/tests/test_smc_audit_corrections.py ................             [ 90%]
backend/tests/test_smc_engine.py ...............                         [ 96%]
backend/tests/test_volumelens_pro.py .........                           [100%]

================= 255 passed, 4 skipped, 4 warnings in 36.05s =================
```

### Dedicated Phase 9.2 Regression Tests (`test_smc_audit_corrections.py`)
```
backend/tests/test_smc_audit_corrections.py::test_indian_cost_delivery_exact_numerical_values PASSED [  6%]
backend/tests/test_smc_audit_corrections.py::test_indian_cost_intraday_exact_numerical_values PASSED [ 12%]
backend/tests/test_smc_audit_corrections.py::test_date_effective_exchange_charges_pre_and_post_oct_2024 PASSED [ 18%]
backend/tests/test_smc_audit_corrections.py::test_independent_gross_vs_net_classification PASSED [ 25%]
backend/tests/test_smc_audit_corrections.py::test_liquidity_sweep_four_stage_lifecycle PASSED [ 31%]
backend/tests/test_smc_audit_corrections.py::test_liquidity_sweep_reclaim_without_opposing_reaction_rejected PASSED [ 37%]
backend/tests/test_smc_audit_corrections.py::test_liquidity_sweep_continuation_breakout_classified_failed PASSED [ 43%]
backend/tests/test_smc_audit_corrections.py::test_strict_position_sizing_rejection PASSED [ 50%]
backend/tests/test_smc_audit_corrections.py::test_multi_window_walk_forward_rolling PASSED [ 56%]
backend/tests/test_smc_audit_corrections.py::test_data_quality_extended_validations PASSED [ 62%]
backend/tests/test_smc_audit_corrections.py::test_all_detectors_pending_availability_on_last_bar PASSED [ 68%]
backend/tests/test_smc_audit_corrections.py::test_dp_charge_settlement_and_isin_modeling PASSED [ 75%]
backend/tests/test_smc_audit_corrections.py::test_wilson_score_confidence_intervals PASSED [ 81%]
backend/tests/test_smc_audit_corrections.py::test_bootstrap_confidence_intervals_and_sample_size_warnings PASSED [ 87%]
backend/tests/test_smc_audit_corrections.py::test_walk_forward_rejects_spurious_robustness_with_small_sample PASSED [ 93%]
backend/tests/test_smc_audit_corrections.py::test_configurable_risk_free_rate_sharpe PASSED [100%]
============================= 16 passed in 1.57s ==============================
```

### Frontend TypeScript & Vite Production Build
```
> stock-intelligence-frontend@0.1.0 build
> tsc && vite build

vite v6.4.5 building for production...
transforming...
✓ 53 modules transformed.
rendering chunks...
computing gzip size...
dist/index.html                   0.36 kB │ gzip:   0.27 kB
dist/assets/index-C9xCwPR6.css   16.69 kB │ gzip:   4.24 kB
dist/assets/index-BcfxGmsS.js   564.22 kB │ gzip: 153.62 kB
✓ built in 1.32s
```

---

## 7. Conclusion

Phase 9.2 achieves final cost-model accuracy and institutional statistical rigor:
1. **Dhan Default Profile** accurately captures ₹0 delivery brokerage, ₹14.75 DP debit per ISIN per settlement day, and min(₹20, 0.03%) intraday brokerage.
2. **Current NSE Cash Schedule** implements ₹306.99/cr transaction fee + ₹0.01/cr IPFT (₹307.00/cr combined) effective 1 March 2026, alongside accurate historical tiers and GST treatment.
3. **Statistical Validation** prevents premature or unearned alpha claims by requiring $\ge 30$ out-of-sample trades, 95% bootstrap lower bound $> 1.00$, and reporting Wilson score confidence intervals.
4. **All 255 Backend Tests Passed** and frontend production build compiled cleanly.
