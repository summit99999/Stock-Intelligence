# STOCK INTELLIGENCE PRO — PHASE 9.3 DELIVERY & AUDIT REPORT
## Dhan DP Billing, Historical NSE Schedules, Continuous Mark-to-Market & Statistical Governance

**Date**: November 5, 2026  
**Project**: Stock Intelligence Pro (`D:\ST\Stock-Intelligence-Starter\Stock-Intelligence`)  
**Target Audience**: Quantitative Audit Committee, Chief Risk Officer, Retail Algorithmic Traders  
**Status**: **IMPLEMENTATION & VERIFICATION COMPLETE (100% PASS RATE)**  

---

## 1. Executive Summary

Phase 9.3 resolves the critical real-world friction and statistical subtleties identified in external review. Rather than making superficial changes, the entire quantitative infrastructure in `backend/app/services/smc_backtest_service.py` was audited, corrected, and verified against published retail broker policies and exchange circulars.

### Key Milestones Delivered:
1. **Dhan DP Early Pay-In (EPI) Model**: Implemented Dhan's confirmed billing policy where demat debit charges are levied per delivery sell order/instruction rather than batched per scrip per day. Provided configurable `dp_policy: "per_order"` (default for Dhan) and `"per_isin_daily"` (CDSL batched debit for Zerodha), with parent order grouping for partial fills.
2. **Rejection of Retail Delivery Overnight Shorting**: In accordance with Indian securities regulations, retail spot delivery shorting is impossible without Securities Lending & Borrowing (SLB). Delivery setups with `direction == "BEARISH"` are formally rejected with `UNSUPPORTED_OVERNIGHT_SHORT`.
3. **5-Tier Historical NSE Cash Market Fee Schedule**: Incorporated complete date-bound tariff schedules spanning circulars `NSE/F&A/66742` (Feb 2026), `NSE/F&A/63799` (Sep 2024), `NSE/F&A/61157` (Mar 2024), `NSE/F&A/55942` (Mar 2023), and `NSE/F&A/1988`. Corrected historical Investor Protection Fund Trust (IPFT) rate to ₹10.00/crore per side.
4. **Itemized Per-Leg Buy & Sell Statutory Ledger**: `calculate_indian_transaction_costs` now exposes explicit `buy_breakdown` and `sell_breakdown` dictionaries detailing turnover, brokerage, STT, exchange charges, IPFT, SEBI fees, stamp duty, GST, DP base, DP GST, and slippage for each trade leg.
5. **Continuous Daily Mark-to-Market Portfolio Equity Curve**: Replaced stepped trade-exit equity tracking with continuous daily valuation. Open positions are marked to market daily via `df["close"]`, intermediate drawdowns are captured, and idle cash days earn 0.0% and are penalized against the assumed risk-free benchmark rate ($-R_{f,\text{daily}}$).
6. **Institutional Statistical Governance**:
   - Sample size validity tier renamed from `ADEQUATE` to `ADEQUATE_FOR_PRELIMINARY_TESTING`, with explicit warnings that point estimates must be evaluated alongside confidence interval bounds.
   - Zero-loss bootstrap resamples capped at `max_pf_cap = 50.0` with explicit tracking.
   - Default bootstrap resamples increased to 5,000 (`n_resamples = 5000`).
   - Lag-1 serial autocorrelation of returns ($\rho_1$) computed, with warnings emitted when $|\rho_1| > 0.2$.
   - Multiple testing / selection bias warning computed via Family-Wise Error Rate (FWER) across parameter perturbation grids.

---

## 2. Dhan DP Billing & Early Pay-In (EPI) Architecture

### Published Broker Mechanics
Traditional depository billing (e.g. CDSL tariff) levies debit charges once per ISIN per settlement date if debited as a single end-of-day batch. However, as documented in Dhan's official pricing and support knowledgebase ([Dhan Freshdesk Solution 82000878181](https://dhan.freshdesk.com/support/solutions/articles/82000878181-dp-charges-will-be-levied-for-every-delivery-sell-order-per-scrip-per-day-for-any-given-quantity-)):

> *"DP charges will be levied for every delivery sell order per scrip per day for any given quantity."*

This occurs because Dhan executes a real-time **Early Pay-In (EPI)** of shares to the Clearing Corporation (CC) at the time each delivery sell order is placed/executed to release 80% trading limits immediately, rather than waiting for the end-of-day settlement batch. Each individual EPI instruction to the depository constitutes an independent debit transaction incurring ₹12.50 base DP fee + 18% GST = ₹14.75.

### Implementation Architecture
In `backend/app/services/smc_backtest_service.py`:
- `BROKER_PROFILES["dhan"]["dp_policy"] = "per_order"` (default).
- `BROKER_PROFILES["zerodha"]["dp_policy"] = "per_isin_daily"`.
- If an order has multiple partial fills, they share a `parent_order_id` or `order_id`, ensuring only 1 DP charge is levied per parent order.
- If two independent sell orders are executed on the same day for `RELIANCE` under Dhan, each incurs ₹14.75, totaling ₹29.50. Under Zerodha, the second sell order on the same day incurs ₹0 DP fee.
- Intraday trades incur ₹0 DP fee across all broker models.

### Retail Delivery Short Selling Rejection
In Indian equity markets, SEBI regulations prohibit retail overnight shorting in the cash/delivery segment unless executed under the institutional Securities Lending & Borrowing (SLB) mechanism. The SMC backtester now strictly enforces this reality:
```python
if direction == "BEARISH" and trade_type == "delivery" and not allow_overnight_short:
    rejected_trades.append({
        "setup_id": sig["setup_id"],
        "entry_bar": entry_bar,
        "entry_time": timestamps.iloc[entry_bar],
        "reason": "UNSUPPORTED_OVERNIGHT_SHORT",
        "detail": "Short selling in Indian cash equity delivery segment is unsupported without Securities Lending & Borrowing (SLB). Intraday shorting is permitted.",
    })
    continue
```

---

## 3. Date-Effective NSE Cash Fee Schedule (5 Historical Tiers)

Circular `NSE/F&A/66742` (Feb 2026) confirmed that the pre-existing IPFT rate was ₹10.00 per crore (not ₹0.10). When NSE revised transaction charges to ₹306.99 per crore from 1 March 2026, it simultaneously reduced IPFT to ₹0.01 per crore to maintain the combined exchange outflow at exactly ₹307.00 per crore per side.

The full date-bound ledger schedule in `smc_backtest_service.py` is configured as follows:

| Tier | Effective Dates | Circular Ref | Txn Charge (₹/cr) | IPFT (₹/cr) | Combined (₹/cr) | Description |
|---|---|---|---|---|---|---|
| **Tier 1 (Current)** | 2026-03-01 to Present | `NSE/F&A/66742` | ₹306.99 | ₹0.01 | **₹307.00** | Current schedule (₹306.99 txn + ₹0.01 IPFT) |
| **Tier 2** | 2024-10-01 to 2026-02-28 | `NSE/F&A/63799` | ₹297.00 | ₹10.00 | **₹307.00** | True-to-label circular (₹297 txn + ₹10 IPFT) |
| **Tier 3** | 2024-04-01 to 2024-09-30 | `NSE/F&A/61157` | ₹322.00 | ₹10.00 | **₹332.00** | Rollback of 6% discount (₹322 txn + ₹10 IPFT) |
| **Tier 4** | 2023-04-01 to 2024-03-31 | `NSE/F&A/55942` | ₹325.00 | ₹10.00 | **₹335.00** | 6% fee concession applied to ₹345 (₹325 txn + ₹10 IPFT) |
| **Tier 5** | Prior to 2023-04-01 | `NSE/F&A/1988` | ₹345.00 | ₹10.00 | **₹355.00** | Standard historical cash tariff (₹345 txn + ₹10 IPFT) |

---

## 4. Itemized Buy/Sell Breakdown: Reliance Numerical Example

### Setup:
- **Quantity**: 100 shares of Reliance Industries (`RELIANCE`)
- **Buy Price**: ₹2,500.00 (Entry turnover = ₹250,000.00 = ₹2.50 Lakh)
- **Sell Price**: ₹2,600.00 (Exit turnover = ₹260,000.00 = ₹2.60 Lakh)
- **Total Turnover**: ₹510,000.00 (₹5.10 Lakh)
- **Broker Profile**: Dhan Retail (Delivery brokerage = ₹0)

### Current Dhan Schedule (From 1 March 2026 onwards):
```
BUY SIDE (Turnover = ₹250,000.00):
  Brokerage:                   ₹0.00
  STT (0.10%):               ₹250.00
  Exchange Txn (₹306.99/cr):    ₹7.67
  IPFT (₹0.01/cr):             ₹0.00025
  SEBI Turnover (₹10/cr):       ₹0.25
  Stamp Duty (0.015%):         ₹37.50
  GST (18% on 7.67 + 0.25):     ₹1.43
  Slippage (5 bps):           ₹125.00
  -----------------------------------
  Statutory Subtotal:         ₹296.85
  Buy Leg Total Outflow:      ₹421.85

SELL SIDE (Turnover = ₹260,000.00):
  Brokerage:                   ₹0.00
  STT (0.10%):               ₹260.00
  Exchange Txn (₹306.99/cr):    ₹7.98
  IPFT (₹0.01/cr):             ₹0.00026
  SEBI Turnover (₹10/cr):       ₹0.26
  Stamp Duty (0.0%):            ₹0.00
  DP Base Charge:              ₹12.50
  DP GST (18%):                 ₹2.25  (Total DP = ₹14.75)
  GST (18% on 7.98 + 0.26):     ₹1.48
  Slippage (5 bps):           ₹130.00
  -----------------------------------
  Statutory Subtotal:         ₹284.47
  Sell Leg Total Outflow:     ₹414.47

COMBINED AUDIT TOTALS:
  Total Statutory Charges:    ₹581.33
  Total Execution Slippage:   ₹255.00
  Total Friction:             ₹836.33
  Effective Friction:         16.40 bps on ₹5.10 Lakh turnover
```

### Pre-March 2026 Historical Schedule (1 Oct 2024 to 28 Feb 2026):
```
BUY SIDE (Turnover = ₹250,000.00):
  Exchange Txn (₹297.00/cr):    ₹7.425 -> ₹7.43
  IPFT (₹10.00/cr):             ₹0.25
  SEBI Turnover:                ₹0.25
  Stamp Duty:                  ₹37.50
  STT:                        ₹250.00
  GST (18% on 7.43 + 0.25):     ₹1.38
  Statutory Subtotal:         ₹296.56

SELL SIDE (Turnover = ₹260,000.00):
  Exchange Txn (₹297.00/cr):    ₹7.722 -> ₹7.72
  IPFT (₹10.00/cr):             ₹0.26
  SEBI Turnover:                ₹0.26
  STT:                        ₹260.00
  DP Total (₹12.50 + 18% GST): ₹14.75
  GST (18% on 7.72 + 0.26):     ₹1.44
  Statutory Subtotal:         ₹284.17

COMBINED AUDIT TOTALS:
  Total Statutory Charges:    ₹580.73
  Total Execution Slippage:   ₹255.00
  Total Friction:             ₹835.73
  Effective Friction:         16.39 bps on ₹5.10 Lakh turnover
```

---

## 5. Continuous Daily Mark-to-Market & Risk-Adjusted Ratios

### The Flaw in Stepped Equity Tracking
Previously, portfolio equity stepped only when a trade closed. On days while a position was held open, equity remained frozen at the entry cash level, hiding intra-trade drawdowns and intermediate volatility from the Sharpe and Sortino denominators.

### True Daily Mark-to-Market Valuation
In Phase 9.3, portfolio equity $E_k$ is tracked on every single trading day $k \in [0, n-1]$:
$$E_k = \text{Initial Capital} + \sum_{t: \text{exit\_bar} \le k} \text{Net PnL}_t + \sum_{t \text{ open at } k} \Big[ \text{Unrealized Gross PnL}(t, k) - \text{Entry Costs}_t \Big]$$

Where:
- For long delivery positions: $\text{Unrealized Gross PnL}(t, k) = \text{Shares}_t \times (P_{\text{close}, k} - P_{\text{entry}, t})$.
- On idle cash days (no open position), $E_k = E_{k-1}$, so daily return $R_k = 0.0$.
- Daily excess return against the assumed benchmark rate is $R_k - R_{f,\text{daily}} = -R_{f,\text{daily}}$, correctly penalizing idle cash for opportunity cost.
- At bar $n-1$, $E_{n-1} = \text{Final Realized Equity}$ exactly, preserving full capital conservation.

### Annualized Sortino Downside Convention
In alignment with institutional standards, the Sortino downside deviation measures dispersion strictly below the daily risk-free benchmark $R_f$:
$$\text{Downside Deviation} = \sqrt{\frac{1}{N} \sum_{k=1}^N \min(R_k - R_{f,\text{daily}}, 0)^2}$$
$$\text{Annualized Sortino} = \frac{\bar{R}_{\text{excess}}}{\text{Downside Deviation}} \times \sqrt{252}$$

---

## 6. Statistical Rigor & Overfitting Governance

### Sample Size Adequacy Tiers
To prevent premature claims of statistical reliability, sample sizes are evaluated under conservative terminology:
- **`CRITICALLY_LOW` ($N < 15$)**: Standard errors are massive; metrics have virtually zero predictive power.
- **`INSUFFICIENT` ($15 \le N < 30$)**: Asymptotic normality assumptions do not hold.
- **`MODERATE` ($30 \le N < 50$)**: Basic statistical inferences can be computed, but confidence intervals remain broad ($\pm 15\text{--}25\%$ on win rates). Point estimates should not be mistaken for statistical certainty.
- **`ADEQUATE_FOR_PRELIMINARY_TESTING` ($N \ge 50$)**: Sufficient for preliminary testing, but point estimates must be evaluated alongside confidence interval bounds. Statistical significance requires lower CI bounds to strictly exceed benchmark thresholds.

### Bootstrap Resampling (5,000 Resamples) & Zero-Loss Handling
- Default resamples increased to $B = 5,000$ (`n_resamples = 5000`) with deterministic `random_seed = 42`.
- When a bootstrap resample draws only winning trades (loss sum = 0.0), profit factor is mathematically infinite. These are capped at `max_pf_cap = 50.0`, with the count tracked in `capped_zero_loss_resamples`.

### Return Serial Autocorrelation ($\rho_1$)
Standard bootstrap confidence intervals assume trade returns are independent and identically distributed (i.i.d.). To detect regime clustering or streak dependence, lag-1 serial autocorrelation is computed:
$$\rho_1 = \frac{\sum_{i=1}^{n-1} (x_i - \bar{x})(x_{i+1} - \bar{x})}{\sum_{i=1}^n (x_i - \bar{x})^2}$$
If $|\rho_1| > 0.2$, an institutional warning is attached to the bootstrap output, indicating that standard i.i.d. resampling may understate confidence interval widths and recommending block bootstrap methods.

### Multiple Testing Selection Bias Warning
In `run_parameter_sensitivity`, testing $M$ parameter configurations over the same dataset creates significant data snooping risk. The system now computes the cumulative Family-Wise Error Rate (FWER) false discovery risk:
$$\text{False Discovery Risk} = 1 - (1 - \alpha)^M$$
For a standard 12-cell grid at $\alpha = 0.05$, the false discovery risk is $1 - (0.95)^{12} \approx 46.0\%$. An explicit warning is attached to remind researchers to validate candidates on walk-forward windows.

---

## 7. Verification Matrix & Test Execution

All 22 audit regression tests in `backend/tests/test_smc_audit_corrections.py` and the complete 255-test backend suite pass with 0 errors.

```
============================= test session starts =============================
platform win32 -- Python 3.12.10, pytest-9.2.0, pluggy-1.7.0
rootdir: D:\ST\Stock-Intelligence-Starter\Stock-Intelligence
collected 22 items in backend/tests/test_smc_audit_corrections.py

test_indian_cost_delivery_exact_numerical_values PASSED                  [  4%]
test_indian_cost_intraday_exact_numerical_values PASSED                  [  9%]
test_date_effective_exchange_charges_all_five_tiers PASSED               [ 13%]
test_independent_gross_vs_net_classification PASSED                     [ 18%]
test_liquidity_sweep_four_stage_lifecycle PASSED                        [ 22%]
test_liquidity_sweep_reclaim_without_opposing_reaction_rejected PASSED   [ 27%]
test_liquidity_sweep_continuation_breakout_classified_failed PASSED     [ 31%]
test_strict_position_sizing_rejection PASSED                            [ 36%]
test_multi_window_walk_forward_rolling PASSED                           [ 40%]
test_data_quality_extended_validations PASSED                           [ 45%]
test_all_detectors_pending_availability_on_last_bar PASSED             [ 50%]
test_dp_charge_settlement_and_isin_modeling PASSED                      [ 54%]
test_wilson_score_confidence_intervals PASSED                           [ 59%]
test_bootstrap_confidence_intervals_and_sample_size_warnings PASSED      [ 63%]
test_walk_forward_rejects_spurious_robustness_with_small_sample PASSED  [ 68%]
test_configurable_risk_free_rate_sharpe PASSED                         [ 72%]
test_dhan_dp_charge_per_order_policy_and_partial_fills PASSED           [ 77%]
test_unsupported_overnight_short_in_delivery_rejected PASSED            [ 81%]
test_continuous_daily_mark_to_market_equity_series PASSED              [ 86%]
test_bootstrap_5000_resamples_zero_loss_cap_and_autocorrelation PASSED  [ 90%]
test_multiple_testing_selection_bias_warning_in_parameter_sensitivity PASSED [ 95%]
test_reliance_numerical_recalculation_current_and_historical_schedules PASSED [100%]

============================= 22 passed in 1.70s ==============================
```

---

## 8. Unresolved Assumptions & Production Recommendations

1. **Intraday Exchange Surcharge Timing**: NSE intra-day trading charges are evaluated uniformly under cash delivery schedules; specific volume-tiered proprietary turnover rebates are omitted for retail realism.
2. **Dhan MTF / SLB Modeling**: Overnight short delivery trades are rejected. If margin trading facility (MTF) or SLB borrowing rates are integrated in future phases, interest carry costs (typically 12–18% p.a.) can be incorporated into daily mark-to-market.
3. **Block Bootstrap for Autocorrelated Strategies**: Where $|\rho_1| > 0.2$, future phases can incorporate Politis-Romano stationary block bootstrap for optimal block-length selection.
